執行方式(擇一):
1.直接用vscode執行py檔
2.把程式碼放到ipynb的一個block執行
3.把程式碼放到ipynb，用google colab執行

在
if __name__=='__main__':
    # Load the data
    category = "Wafer" # Wafer / ECG200
可以把dataset換成Wafer或是ECG200