執行方式(擇一):
1.直接用vscode執行py檔
2.把程式碼放到ipynb的一個block執行
3.把程式碼放到ipynb，用google colab執行